/*
 * File: Hercules.h
 *
 * Code generated for Simulink model 'Hercules'.
 *
 * Model version                  : 1.120
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Tue Apr  6 08:59:44 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Hercules_h_
#define RTW_HEADER_Hercules_h_
#include "rtwtypes.h"
#ifndef Hercules_COMMON_INCLUDES_
#define Hercules_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* Hercules_COMMON_INCLUDES_ */

/* Child system includes */
#include "Power_System_General.h"

/* Model Code Variants */

/* Macros for accessing real-time model data structure */
#ifndef DEFINED_TYPEDEF_FOR_enPowerStates_t_
#define DEFINED_TYPEDEF_FOR_enPowerStates_t_

/* Power System Sequence States */
typedef enum {
  enPowerStates_t_None = 0,            /* Default value */
  enPowerStates_t_StartupHercules,
  enPowerStates_t_StartupJetson,
  enPowerStates_t_AllOn,
  enPowerStates_t_PowerOff,
  enPowerStates_t_ShutdownJetson,
  enPowerStates_t_JetsonOff,
  enPowerStates_t_ShutdownHercules,
  enPowerStates_t_ResetJetson,
  enPowerStates_t_ForcedRecoveryJetson,
  enPowerStates_t_JetsonStarting,
  enPowerStates_t_JetsonShuttingDown,
  enPowerStates_t_EnterForcedRecoveryJetson
} enPowerStates_t;

#endif

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  Power_System_General_MdlrefDW Power_System_InstanceData;/* '<Root>/Power_System' */
  uint8_T is_active_c7_Hercules;       /* '<S2>/SPIvariableUpdate' */
  uint8_T is_c7_Hercules;              /* '<S2>/SPIvariableUpdate' */
  uint8_T PrevVariable;                /* '<S2>/SPIvariableUpdate' */
} DW;

/* Block signals and states (default storage) */
extern DW rtDW;

/* Model entry point functions */
extern void Hercules_initialize(void);
extern void Hercules_step(void);

/* Exported data declaration */

/* Data with Exported storage */
extern enPowerStates_t rtPowerState;   /* '<Root>/PowerState' */
extern boolean_T rtPwrOn;              /* '<Root>/powerOn' */
extern real_T rtRSSIa_Samples;         /* '<Root>/RSSIa_Samples' */
extern real_T rtRSSIb_Samples;         /* '<Root>/RSSIb_Samples' */
extern real_T rtRSSIc_Samples;         /* '<Root>/RSSIc_Samples' */
extern uint8_T rtRSSIgain;             /* '<Root>/RSSIgain' */
extern boolean_T rtRSSIgainUpdated;    /* '<Root>/RSSIgainUpdated' */
extern boolean_T rtUpdateRSSIgain;     /* '<Root>/UpdateRSSIgain' */
extern boolean_T rtenableRSSIopAmps;   /* '<Root>/enableRSSIopAmps' */
extern boolean_T rtjetsonFCTR;         /* '<Root>/jetsonFCTR' */
extern boolean_T rtjetsonOn;           /* '<Root>/jetsonOn' */
extern boolean_T rtjetsonPwrBtn;       /* '<Root>/jetsonPwrBtn' */
extern boolean_T rtjetsonRestet;       /* '<Root>/jetsonRestet' */
extern boolean_T rtlatch;              /* '<Root>/powerLatch' */
extern boolean_T rtlowerLimit;         /* '<Root>/lowerLimit' */
extern enPowerStates_t rtpowerStateReq;/* '<Root>/powerStateReq' */
extern uint16_T rtrawRSSIa;            /* '<Root>/rawRSSI_A' */
extern uint16_T rtrawRSSIb;            /* '<Root>/rawRSSI_B' */
extern uint16_T rtrawRSSIc;            /* '<Root>/rawRSSI_C' */
extern boolean_T rtshutdown;           /* '<Root>/shutdown' */
extern boolean_T rtupperLimit;         /* '<Root>/upperLimit' */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Hercules'
 * '<S1>'   : 'Hercules/Compare To Zero'
 * '<S2>'   : 'Hercules/Subsystem'
 * '<S3>'   : 'Hercules/Subsystem/SPIvariableUpdate'
 */
#endif                                 /* RTW_HEADER_Hercules_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
