/*
 * File: Hercules.c
 *
 * Code generated for Simulink model 'Hercules'.
 *
 * Model version                  : 1.120
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Tue Apr  6 08:59:44 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "Hercules.h"

/* Named constants for Chart: '<S2>/SPIvariableUpdate' */
#define IN_Idle                        ((uint8_T)1U)
#define IN_UpdateGain                  ((uint8_T)2U)

/* Exported data definition */

/* Data with Exported storage */
enPowerStates_t rtPowerState;          /* '<Root>/PowerState' */
boolean_T rtPwrOn;                     /* '<Root>/powerOn' */
real_T rtRSSIa_Samples;                /* '<Root>/RSSIa_Samples' */
real_T rtRSSIb_Samples;                /* '<Root>/RSSIb_Samples' */
real_T rtRSSIc_Samples;                /* '<Root>/RSSIc_Samples' */
uint8_T rtRSSIgain;                    /* '<Root>/RSSIgain' */
boolean_T rtRSSIgainUpdated;           /* '<Root>/RSSIgainUpdated' */
boolean_T rtUpdateRSSIgain;            /* '<Root>/UpdateRSSIgain' */
boolean_T rtenableRSSIopAmps;          /* '<Root>/enableRSSIopAmps' */
boolean_T rtjetsonFCTR;                /* '<Root>/jetsonFCTR' */
boolean_T rtjetsonOn;                  /* '<Root>/jetsonOn' */
boolean_T rtjetsonPwrBtn;              /* '<Root>/jetsonPwrBtn' */
boolean_T rtjetsonRestet;              /* '<Root>/jetsonRestet' */
boolean_T rtlatch;                     /* '<Root>/powerLatch' */
boolean_T rtlowerLimit;                /* '<Root>/lowerLimit' */
enPowerStates_t rtpowerStateReq;       /* '<Root>/powerStateReq' */
uint16_T rtrawRSSIa;                   /* '<Root>/rawRSSI_A' */
uint16_T rtrawRSSIb;                   /* '<Root>/rawRSSI_B' */
uint16_T rtrawRSSIc;                   /* '<Root>/rawRSSI_C' */
boolean_T rtshutdown;                  /* '<Root>/shutdown' */
boolean_T rtupperLimit;                /* '<Root>/upperLimit' */

// rtrawRSSIa[0];
//adcData_t rtrawRSSIb[1];
//adcData_t rtrawRSSIc[2];


/* Block signals and states (default storage) */
DW rtDW;

/* Model step function */
void Hercules_step(void)
{
  /* ModelReference: '<Root>/Power_System' incorporates:
   *  Inport: '<Root>/jetsonOn'
   *  Inport: '<Root>/powerLatch'
   *  Inport: '<Root>/powerOn'
   *  Inport: '<Root>/powerStateReq'
   *  Outport: '<Root>/jetsonFCTR'
   *  Outport: '<Root>/jetsonPwrBtn'
   *  Outport: '<Root>/jetsonRestet'
   *  Outport: '<Root>/shutdown'
   */
  Power_System_General((&(rtjetsonOn)), (&(rtPwrOn)), (&(rtpowerStateReq)),
                       (&(rtjetsonPwrBtn)), (&(rtjetsonFCTR)), (&(rtjetsonRestet)),
                       (&(rtshutdown)), &(rtDW.Power_System_InstanceData.rtdw));

  /* Chart: '<S2>/SPIvariableUpdate' incorporates:
   *  Inport: '<Root>/RSSIgain'
   *  Inport: '<Root>/RSSIgainUpdated'
   */
  /* Gateway: Subsystem/SPIvariableUpdate */
  /* During: Subsystem/SPIvariableUpdate */
  if (rtDW.is_active_c7_Hercules == 0U) {
    /* Entry: Subsystem/SPIvariableUpdate */
    rtDW.is_active_c7_Hercules = 1U;

    /* Entry Internal: Subsystem/SPIvariableUpdate */
    /* Transition: '<S3>:2' */
    rtDW.is_c7_Hercules = IN_Idle;

    /* Outport: '<Root>/UpdateRSSIgain' */
    /* Entry 'Idle': '<S3>:1' */
    rtUpdateRSSIgain = false;
  } else if (rtDW.is_c7_Hercules == IN_Idle) {
    /* Outport: '<Root>/UpdateRSSIgain' */
    rtUpdateRSSIgain = false;

    /* During 'Idle': '<S3>:1' */
    if (rtRSSIgain != rtDW.PrevVariable) {
      /* Transition: '<S3>:5' */
      rtDW.is_c7_Hercules = IN_UpdateGain;

      /* Outport: '<Root>/UpdateRSSIgain' */
      /* Entry 'UpdateGain': '<S3>:3' */
      rtUpdateRSSIgain = true;
      rtDW.PrevVariable = rtRSSIgain;
    }
  } else {
    /* Outport: '<Root>/UpdateRSSIgain' */
    rtUpdateRSSIgain = true;

    /* During 'UpdateGain': '<S3>:3' */
    if (rtRSSIgainUpdated) {
      /* Transition: '<S3>:6' */
      rtDW.is_c7_Hercules = IN_Idle;

      /* Outport: '<Root>/UpdateRSSIgain' */
      /* Entry 'Idle': '<S3>:1' */
      rtUpdateRSSIgain = false;
    }
  }

  /* End of Chart: '<S2>/SPIvariableUpdate' */

  /* Outport: '<Root>/enableRSSIopAmps' incorporates:
   *  Constant: '<S1>/Constant'
   *  Inport: '<Root>/RSSIgain'
   *  RelationalOperator: '<S1>/Compare'
   */
  rtenableRSSIopAmps = (rtRSSIgain > 0);
}

/* Model initialize function */
void Hercules_initialize(void)
{
  /* SystemInitialize for ModelReference: '<Root>/Power_System' incorporates:
   *  Inport: '<Root>/jetsonOn'
   *  Inport: '<Root>/powerLatch'
   *  Inport: '<Root>/powerOn'
   *  Inport: '<Root>/powerStateReq'
   *  Outport: '<Root>/jetsonFCTR'
   *  Outport: '<Root>/jetsonPwrBtn'
   *  Outport: '<Root>/jetsonRestet'
   *  Outport: '<Root>/shutdown'
   */
  Power_System_General_Init(&(rtDW.Power_System_InstanceData.rtdw));

  /* ConstCode for Outport: '<Root>/PowerState' */
  rtPowerState = enPowerStates_t_None;
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
