/*
 * File: Power_System_General.c
 *
 * Code generated for Simulink model 'Power_System_General'.
 *
 * Model version                  : 1.145
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Wed Mar 31 15:03:15 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "Power_System_General.h"

/* Named constants for Chart: '<Root>/PowerSystem' */
#define Power_System_G_IN_AwaitShutDown ((uint8_T)1U)
#define Power_System_Gen_IN_HerculesOFF ((uint8_T)1U)
#define Power_System_Gen_IN_Operational ((uint8_T)2U)
#define Power_System_Gene_IN_HerculesON ((uint8_T)2U)
#define Power_System_Gener_IN_JetsonOFF ((uint8_T)1U)
#define Power_System_Gener_IN_StartUp_f ((uint8_T)4U)
#define Power_System_Genera_IN_JetsonON ((uint8_T)1U)
#define Power_System_Genera_IN_ShutDown ((uint8_T)2U)
#define Power_System_General_IN_Reset  ((uint8_T)3U)
#define Power_System_General_IN_StartUp ((uint8_T)2U)
#define Power_System_IN_NO_ACTIVE_CHILD ((uint8_T)0U)
#define Power_System__IN_ForcedRecovery ((uint8_T)1U)

/* System initialize for referenced model: 'Power_System_General' */
void Power_System_General_Init(Power_System_General_DW_f *localDW)
{
  /* SystemInitialize for Chart: '<Root>/PowerSystem' */
  localDW->PowerStateReq_prev = enPowerStates_t_None;
  localDW->PowerStateReq_start = enPowerStates_t_None;
}

/* Output and update for referenced model: 'Power_System_General' */
void Power_System_General(const boolean_T *rtu_jetsonOn, const boolean_T
  *rtu_powerOn, const enPowerStates_t *rtu_PowerStateReq, boolean_T
  *rty_jetsonPwrBtn, boolean_T *rty_jetsonFCTR, boolean_T *rty_jetsonRestet,
  boolean_T *rty_shutdown, Power_System_General_DW_f *localDW)
{
  /* Chart: '<Root>/PowerSystem' */
  if (localDW->temporalCounter_i1 < MAX_uint32_T) {
    localDW->temporalCounter_i1++;
  }

  /* Gateway: PowerSystem */
  localDW->PowerStateReq_prev = localDW->PowerStateReq_start;
  localDW->PowerStateReq_start = *rtu_PowerStateReq;
  localDW->PowerOn_prev = localDW->PowerOn_start;
  localDW->PowerOn_start = *rtu_powerOn;
  localDW->jetsonOn_prev = localDW->jetsonOn_start;
  localDW->jetsonOn_start = *rtu_jetsonOn;

  /* During: PowerSystem */
  if (localDW->is_active_c1_Power_System_Gener == 0U) {
    localDW->PowerStateReq_prev = *rtu_PowerStateReq;
    localDW->PowerOn_prev = *rtu_powerOn;
    localDW->jetsonOn_prev = *rtu_jetsonOn;

    /* Entry: PowerSystem */
    localDW->is_active_c1_Power_System_Gener = 1U;

    /* Entry Internal: PowerSystem */
    /* Transition: '<S1>:152' */
    localDW->jetsonOff = true;
    *rty_shutdown = false;
    *rty_jetsonFCTR = false;
    localDW->is_c1_Power_System_General = Power_System_Gen_IN_HerculesOFF;

    /* Entry 'HerculesOFF': '<S1>:130' */
    *rty_jetsonPwrBtn = false;

    /* Entry Internal 'HerculesOFF': '<S1>:130' */
    /* Transition: '<S1>:136' */
    localDW->is_HerculesOFF = Power_System_Gener_IN_JetsonOFF;

    /* Entry Internal 'JetsonOFF': '<S1>:126' */
    /* Transition: '<S1>:137' */
    localDW->is_JetsonOFF = Power_System_G_IN_AwaitShutDown;
    localDW->temporalCounter_i1 = 0U;
  } else if (localDW->is_c1_Power_System_General ==
             Power_System_Gen_IN_HerculesOFF) {
    *rty_jetsonPwrBtn = false;

    /* During 'HerculesOFF': '<S1>:130' */
    if ((localDW->PowerOn_prev != localDW->PowerOn_start) &&
        localDW->PowerOn_start) {
      /* Transition: '<S1>:131' */
      /* Exit Internal 'HerculesOFF': '<S1>:130' */
      /* Exit Internal 'JetsonOFF': '<S1>:126' */
      localDW->is_JetsonOFF = Power_System_IN_NO_ACTIVE_CHILD;
      localDW->is_HerculesOFF = Power_System_IN_NO_ACTIVE_CHILD;
      localDW->is_c1_Power_System_General = Power_System_Gene_IN_HerculesON;

      /* Entry Internal 'HerculesON': '<S1>:117' */
      /* Transition: '<S1>:142' */
      localDW->is_HerculesON = Power_System_General_IN_StartUp;
      localDW->temporalCounter_i1 = 0U;

      /* Entry 'StartUp': '<S1>:140' */
    } else if (localDW->is_HerculesOFF == Power_System_Gener_IN_JetsonOFF) {
      /* During 'JetsonOFF': '<S1>:126' */
      if (localDW->jetsonOff) {
        /* Transition: '<S1>:150' */
        /* Exit Internal 'JetsonOFF': '<S1>:126' */
        localDW->is_JetsonOFF = Power_System_IN_NO_ACTIVE_CHILD;
        localDW->is_HerculesOFF = Power_System_Genera_IN_ShutDown;

        /* Entry 'ShutDown': '<S1>:132' */
        *rty_shutdown = true;
      } else if (((*rtu_PowerStateReq ==
                   enPowerStates_t_EnterForcedRecoveryJetson) &&
                  localDW->jetsonOff) || ((localDW->jetsonOn_prev !=
                   localDW->jetsonOn_start) && localDW->jetsonOn_start)) {
        /* Transition: '<S1>:155' */
        /* Transition: '<S1>:154' */
        /* Transition: '<S1>:168' */
        /* Transition: '<S1>:167' */
        /* Exit Internal 'JetsonOFF': '<S1>:126' */
        localDW->is_JetsonOFF = Power_System_IN_NO_ACTIVE_CHILD;
        localDW->is_HerculesOFF = Power_System_IN_NO_ACTIVE_CHILD;
        localDW->is_c1_Power_System_General = Power_System_Gene_IN_HerculesON;
        localDW->is_HerculesON = Power_System_Genera_IN_JetsonON;

        /* Entry 'JetsonON': '<S1>:110' */
        *rty_jetsonPwrBtn = true;

        /* Entry Internal 'JetsonON': '<S1>:110' */
        /* Transition: '<S1>:125' */
        localDW->is_JetsonON = Power_System_Gener_IN_StartUp_f;
        localDW->temporalCounter_i1 = 0U;
      } else if ((localDW->is_JetsonOFF == Power_System_G_IN_AwaitShutDown) &&
                 (localDW->temporalCounter_i1 >= 2U)) {
        /* During 'AwaitShutDown': '<S1>:127' */
        /* Transition: '<S1>:133' */
        localDW->is_JetsonOFF = Power_System_Genera_IN_ShutDown;

        /* Entry 'ShutDown': '<S1>:129' */
        localDW->jetsonOff = true;
      } else {
        /* During 'ShutDown': '<S1>:129' */
      }
    } else {
      /* During 'ShutDown': '<S1>:132' */
    }
  } else {
    /* During 'HerculesON': '<S1>:117' */
    if ((localDW->PowerOn_prev != localDW->PowerOn_start) &&
        (!localDW->PowerOn_start)) {
      /* Transition: '<S1>:144' */
      /* Exit Internal 'HerculesON': '<S1>:117' */
      switch (localDW->is_HerculesON) {
       case Power_System_Genera_IN_JetsonON:
        /* Exit Internal 'JetsonON': '<S1>:110' */
        if (localDW->is_JetsonON == Power_System_General_IN_Reset) {
          /* Exit 'Reset': '<S1>:113' */
          *rty_jetsonRestet = false;
          localDW->is_JetsonON = Power_System_IN_NO_ACTIVE_CHILD;
        } else {
          localDW->is_JetsonON = Power_System_IN_NO_ACTIVE_CHILD;
        }

        localDW->is_HerculesON = Power_System_IN_NO_ACTIVE_CHILD;
        break;

       case Power_System_General_IN_StartUp:
        /* Exit 'StartUp': '<S1>:140' */
        *rty_shutdown = false;
        localDW->is_HerculesON = Power_System_IN_NO_ACTIVE_CHILD;
        break;
      }

      localDW->is_c1_Power_System_General = Power_System_Gen_IN_HerculesOFF;

      /* Entry 'HerculesOFF': '<S1>:130' */
      *rty_jetsonPwrBtn = false;

      /* Entry Internal 'HerculesOFF': '<S1>:130' */
      /* Transition: '<S1>:136' */
      localDW->is_HerculesOFF = Power_System_Gener_IN_JetsonOFF;

      /* Entry Internal 'JetsonOFF': '<S1>:126' */
      /* Transition: '<S1>:137' */
      localDW->is_JetsonOFF = Power_System_G_IN_AwaitShutDown;
      localDW->temporalCounter_i1 = 0U;
    } else if (localDW->is_HerculesON == Power_System_Genera_IN_JetsonON) {
      *rty_jetsonPwrBtn = true;

      /* During 'JetsonON': '<S1>:110' */
      if (((localDW->jetsonOn_prev != localDW->jetsonOn_start) &&
           (!localDW->jetsonOn_start)) || ((localDW->PowerStateReq_prev !=
            localDW->PowerStateReq_start) && (localDW->PowerStateReq_start ==
            enPowerStates_t_EnterForcedRecoveryJetson))) {
        /* Transition: '<S1>:153' */
        /* Exit Internal 'JetsonON': '<S1>:110' */
        if (localDW->is_JetsonON == Power_System_General_IN_Reset) {
          /* Exit 'Reset': '<S1>:113' */
          *rty_jetsonRestet = false;
          localDW->is_JetsonON = Power_System_IN_NO_ACTIVE_CHILD;
        } else {
          localDW->is_JetsonON = Power_System_IN_NO_ACTIVE_CHILD;
        }

        localDW->is_HerculesON = Power_System_IN_NO_ACTIVE_CHILD;
        localDW->is_c1_Power_System_General = Power_System_Gen_IN_HerculesOFF;

        /* Entry 'HerculesOFF': '<S1>:130' */
        *rty_jetsonPwrBtn = false;
        localDW->is_HerculesOFF = Power_System_Gener_IN_JetsonOFF;

        /* Entry Internal 'JetsonOFF': '<S1>:126' */
        /* Transition: '<S1>:137' */
        localDW->is_JetsonOFF = Power_System_G_IN_AwaitShutDown;
        localDW->temporalCounter_i1 = 0U;
      } else {
        switch (localDW->is_JetsonON) {
         case Power_System__IN_ForcedRecovery:
          /* During 'ForcedRecovery': '<S1>:158' */
          if ((localDW->PowerStateReq_prev != localDW->PowerStateReq_start) &&
              (localDW->PowerStateReq_prev ==
               enPowerStates_t_EnterForcedRecoveryJetson)) {
            /* Transition: '<S1>:161' */
            *rty_jetsonFCTR = false;

            /* Transition: '<S1>:172' */
            localDW->is_JetsonON = Power_System_IN_NO_ACTIVE_CHILD;
            localDW->is_HerculesON = Power_System_IN_NO_ACTIVE_CHILD;
            localDW->is_c1_Power_System_General =
              Power_System_Gen_IN_HerculesOFF;

            /* Entry 'HerculesOFF': '<S1>:130' */
            *rty_jetsonPwrBtn = false;
            localDW->is_HerculesOFF = Power_System_Gener_IN_JetsonOFF;

            /* Entry Internal 'JetsonOFF': '<S1>:126' */
            /* Transition: '<S1>:137' */
            localDW->is_JetsonOFF = Power_System_G_IN_AwaitShutDown;
            localDW->temporalCounter_i1 = 0U;
          }
          break;

         case Power_System_Gen_IN_Operational:
          /* During 'Operational': '<S1>:119' */
          if ((localDW->PowerStateReq_prev != localDW->PowerStateReq_start) &&
              (localDW->PowerStateReq_start == enPowerStates_t_ResetJetson)) {
            /* Transition: '<S1>:139' */
            /* Transition: '<S1>:122' */
            localDW->is_JetsonON = Power_System_General_IN_Reset;
            localDW->temporalCounter_i1 = 0U;

            /* Entry 'Reset': '<S1>:113' */
            *rty_jetsonRestet = true;
          }
          break;

         case Power_System_General_IN_Reset:
          /* During 'Reset': '<S1>:113' */
          if ((uint32_T)((int32_T)localDW->temporalCounter_i1 * 300) >= 15U) {
            /* Transition: '<S1>:124' */
            /* Exit 'Reset': '<S1>:113' */
            *rty_jetsonRestet = false;
            localDW->is_JetsonON = Power_System_Gener_IN_StartUp_f;
            localDW->temporalCounter_i1 = 0U;
          }
          break;

         default:
          /* During 'StartUp': '<S1>:112' */
          if (*rtu_PowerStateReq == enPowerStates_t_EnterForcedRecoveryJetson) {
            /* Transition: '<S1>:159' */
            localDW->is_JetsonON = Power_System__IN_ForcedRecovery;

            /* Entry 'ForcedRecovery': '<S1>:158' */
            *rty_jetsonFCTR = true;
          } else {
            if (localDW->temporalCounter_i1 >= 2U) {
              /* Transition: '<S1>:138' */
              localDW->is_JetsonON = Power_System_Gen_IN_Operational;

              /* Entry 'Operational': '<S1>:119' */
              localDW->jetsonOff = false;
            }
          }
          break;
        }
      }
    } else {
      /* During 'StartUp': '<S1>:140' */
      if ((uint32_T)((int32_T)localDW->temporalCounter_i1 * 300) >= 15U) {
        /* Transition: '<S1>:141' */
        /* Exit 'StartUp': '<S1>:140' */
        *rty_shutdown = false;
        localDW->is_HerculesON = Power_System_Genera_IN_JetsonON;

        /* Entry 'JetsonON': '<S1>:110' */
        *rty_jetsonPwrBtn = true;

        /* Entry Internal 'JetsonON': '<S1>:110' */
        /* Transition: '<S1>:125' */
        localDW->is_JetsonON = Power_System_Gener_IN_StartUp_f;
        localDW->temporalCounter_i1 = 0U;
      }
    }
  }

  /* End of Chart: '<Root>/PowerSystem' */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
