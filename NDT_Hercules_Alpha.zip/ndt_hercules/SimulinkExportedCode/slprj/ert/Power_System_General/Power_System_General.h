/*
 * File: Power_System_General.h
 *
 * Code generated for Simulink model 'Power_System_General'.
 *
 * Model version                  : 1.145
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Wed Mar 31 15:03:15 2021
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Power_System_General_h_
#define RTW_HEADER_Power_System_General_h_
#include "rtwtypes.h"
#ifndef Power_System_General_COMMON_INCLUDES_
#define Power_System_General_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                               /* Power_System_General_COMMON_INCLUDES_ */

/* Model Code Variants */
#ifndef DEFINED_TYPEDEF_FOR_enPowerStates_t_
#define DEFINED_TYPEDEF_FOR_enPowerStates_t_

/* Power System Sequence States */
typedef enum {
  enPowerStates_t_None = 0,            /* Default value */
  enPowerStates_t_StartupHercules,
  enPowerStates_t_StartupJetson,
  enPowerStates_t_AllOn,
  enPowerStates_t_PowerOff,
  enPowerStates_t_ShutdownJetson,
  enPowerStates_t_JetsonOff,
  enPowerStates_t_ShutdownHercules,
  enPowerStates_t_ResetJetson,
  enPowerStates_t_ForcedRecoveryJetson,
  enPowerStates_t_JetsonStarting,
  enPowerStates_t_JetsonShuttingDown,
  enPowerStates_t_EnterForcedRecoveryJetson
} enPowerStates_t;

#endif

/* Block signals and states (default storage) for model 'Power_System_General' */
typedef struct {
  uint32_T temporalCounter_i1;         /* '<Root>/PowerSystem' */
  enPowerStates_t PowerStateReq_prev;  /* '<Root>/PowerSystem' */
  enPowerStates_t PowerStateReq_start; /* '<Root>/PowerSystem' */
  uint8_T is_active_c1_Power_System_Gener;/* '<Root>/PowerSystem' */
  uint8_T is_c1_Power_System_General;  /* '<Root>/PowerSystem' */
  uint8_T is_HerculesON;               /* '<Root>/PowerSystem' */
  uint8_T is_JetsonON;                 /* '<Root>/PowerSystem' */
  uint8_T is_HerculesOFF;              /* '<Root>/PowerSystem' */
  uint8_T is_JetsonOFF;                /* '<Root>/PowerSystem' */
  boolean_T jetsonOff;                 /* '<Root>/PowerSystem' */
  boolean_T PowerOn_prev;              /* '<Root>/PowerSystem' */
  boolean_T PowerOn_start;             /* '<Root>/PowerSystem' */
  boolean_T jetsonOn_prev;             /* '<Root>/PowerSystem' */
  boolean_T jetsonOn_start;            /* '<Root>/PowerSystem' */
} Power_System_General_DW_f;

typedef struct {
  Power_System_General_DW_f rtdw;
} Power_System_General_MdlrefDW;

extern void Power_System_General_Init(Power_System_General_DW_f *localDW);
extern void Power_System_General(const boolean_T *rtu_jetsonOn, const boolean_T *
  rtu_powerOn, const enPowerStates_t *rtu_PowerStateReq, boolean_T
  *rty_jetsonPwrBtn, boolean_T *rty_jetsonFCTR, boolean_T *rty_jetsonRestet,
  boolean_T *rty_shutdown, Power_System_General_DW_f *localDW);

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Power_System_General'
 * '<S1>'   : 'Power_System_General/PowerSystem'
 */
#endif                                 /* RTW_HEADER_Power_System_General_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
