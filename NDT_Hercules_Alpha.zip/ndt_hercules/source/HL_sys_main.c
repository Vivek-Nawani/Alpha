/** @file HL_sys_main.c
*   @brief Application main file
*   @date 11-Dec-2018
*   @version 04.07.01
*
*   This file contains an empty main function,
*   which can be used for the application.
*/

/* 
* Copyright (C) 2009-2018 Texas Instruments Incorporated - www.ti.com  
* 
* 
*  Redistribution and use in source and binary forms, with or without 
*  modification, are permitted provided that the following conditions 
*  are met:
*
*    Redistributions of source code must retain the above copyright 
*    notice, this list of conditions and the following disclaimer.
*
*    Redistributions in binary form must reproduce the above copyright
*    notice, this list of conditions and the following disclaimer in the 
*    documentation and/or other materials provided with the   
*    distribution.
*
*    Neither the name of Texas Instruments Incorporated nor the names of
*    its contributors may be used to endorse or promote products derived
*    from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
*  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
*  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*
*/


/* USER CODE BEGIN (0) */

/* USER CODE END */

/* Include Files */

#include "HL_sys_common.h"

/* USER CODE BEGIN (1) */

/* FreeRTOS scheduler files */
#include "FreeRTOS.h"
#include "FreeRTOS_UDP_IP.h"
#include "os_task.h"
#include "FreeRTOS_sockets.h"
#include "os_timer.h"
#include "HL_emac.h"
#include "HL_hw_reg_access.h"
#include "HL_spi.h"
#include "HL_gio.h"
#include "HL_sys_pmu.h"
#include "HL_adc.h"

/* Console IO Support */
#include "HL_sci.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>


/* Simulink header */
#include "Hercules.h"

/*Maths Operations */
#include "math.h"



/**  DEFINE  **/
#define sciREGx  sciREG1
#define clearScreen() printf("\033[H\033[J")
#define gotoxy(x,y) printf("\033[%d;%dH", (x), (y))
#define DEBUG_STRING_BUFFER_SIZE 1024
#define TX_BUFFER_SIZE 100 // Buffer size to transmit data to Jetson via UDP
#define RX_BUFFER_SIZE 10 //Buffer size to receive data from Jetson via UDP
#define pdFREERTOS_ERRNO_EWOULDBLOCK -2 // Manually define `pdFREERTOS_ERRNO_EWOULDBLOCK`
uint8_t txtCRLF[] = {'\r', '\n'};
char    printBuffer [512];

#define DebugOn         0


// Define constants for proximity sensors
#define PULSES_PER_METER 100
#define CABLE_LENGTH_PER_TOOTH 1  // Since 0.1m * 10 (scaling factor to avoid float) = 1
#define SENSOR1 0x01
#define SENSOR2 0x02
#define PROX1_FWD_DIR 11
#define PROX1_REV_DIR 12
#define PROX2_FWD_DIR 21
#define PROX2_REV_DIR 22

#define SENSOR_ERROR 32700  // If sensor is not connected, adc throw 32750 count.
#define SENSOR_THRESHOLD 37400  // If sensor is connected and no wire fault detected, adc throw 37520 count.
#define STOPCHECKLIMIT 5
#define CABLE_MIN_LENGTH 0.0  // minimum length of cable in meters
#define CABLE_MAX_LENGTH 100.0  // maximum length of cable in meters
#define FLOAT_INT_MUL_FACTOR 10 // Float to int multiplication factor for cable

#define STABLIZING_FACTOR 5  //Direction Determination Stabilization Factor
#define STABLIZING_FACTOR_RESET 0  //Direction Determination Stabilization Factor Reset

// Define the timeout period (in 100 milliseconds)
#define TIMEOUT_100MS 100

//.... Declarations ......
boolean PROX1_A_Flag = false;
boolean PROX1_B_Flag = false;
boolean PROX2_A_Flag = false;
boolean PROX2_B_Flag = false;


uint16_t PROX1_A_Counter = 0;
uint16_t PROX1_B_Counter = 0;
uint16_t PROX2_A_Counter = 0;
uint16_t PROX2_B_Counter = 0;
uint16_t lastCheckCounter = 0;
uint16_t stopCheckCounter = 0;

uint16_t cableLengthSensor1 = 0;
uint16_t cableLengthSensor2 = 0;
uint16_t pulses = 0;

volatile int32_t  receivedBytes=0;

uint8_t Sys_Reset_Flag=0; // Reset flag

uint8_t S1_Err_OpenCircuit = 0; // Diagnostic Error: Sensor 1 Signal open circuit detect
uint8_t S2_Err_OpenCircuit = 0; // Diagnostic Error: Sensor 2 Signal open circuit detect
uint8_t prox1_Direction=0;
uint8_t prox2_Direction=0;
uint8_t direction_stable_count=0;
uint8_t direction_stable_count2=0;
//uint8_t sizeData =0;
size_t sizeData =0;

static float cable_length_float1 = 0.0; // Current cable length from prox 1 sensor
static float cable_length_float2 = 0.0; // Current cable length from prox 2 sensor
uint16_t cable_length_uint1 = 0; // Float to int conversion as UDP float data transmission didnt receive the correct value. Hence remedy adopted is convert float to int and transimt on udp
uint16_t cable_length_uint2 = 0; // Float to int conversion as UDP float data transmission didnt receive the correct value. Hence remedy adopted is convert float to int and transimt on udp


//..... Cable length calculation variables:
static uint16_t last_1A_counter = 0; // Previous value of counter A from prox 1 sensor
static uint16_t last_1B_counter = 0; // Previous value of counter B from prox 1 sensor
static uint16_t last_2A_counter = 0; // Previous value of counter A from prox 2 sensor
static uint16_t last_2B_counter = 0; // Previous value of counter B from prox 2 sensor

int16_t delta_1A_counter = 0;
int16_t delta_1B_counter = 0;
int16_t delta_2A_counter = 0;
int16_t delta_2B_counter = 0;

float cable_length_change1 = 0.0;
float cable_length_change2 = 0.0;


//AD7175_8_Setup
#define NumEnabledChannelsBitMask 15   // binary bit mask value for number of channels enabled
#define cNDT1SensorCH   0
#define cNDT1NoiseCH    1
#define cNDT2SensorCH   2
#define cNDT2NoiseCH    3

/* Define the network addressing.  These parameters will be used if either
 * ipconfigUDE_DHCP is 0 or if ipconfigUSE_DHCP is 1 but DHCP auto configuration
 * failed. */
//Set to static IP for se on current scaler setup
//[TODO] Update IP address to Scaler assigned
//static const uint8_t ucIPAddress[ 4 ]        = { 10, 0, 0, 98 };
//static const uint8_t ucNetMask[ 4 ]          = { 255, 255, 255, 0 };
//static const uint8_t ucGatewayAddress[ 4 ]   = { 10, 0, 0, 138 };
//static const uint8_t ucDNSServerAddress[ 4 ] = { 10, 0, 0, 100 };

static const uint8_t ucIPAddress[ 4 ]        = { 192, 168, 169, 8 };
static const uint8_t ucNetMask[ 4 ]          = { 255, 255, 255, 0 };
static const uint8_t ucGatewayAddress[ 4 ]   = { 192, 168, 169, 204 };
static const uint8_t ucDNSServerAddress[ 4 ] = { 192, 168, 169, 204 };

/* SPI variables */
uint16_t txSPIbuffer[]= {0x0,0x0,0x0,0x0,0x0};
uint16 txDataLowByte = 0;
uint16 txDataHighByte = 0;
uint16_t rxBuffer[10];
uint16_t BufId = 0;
spiDAT1_t AD7175_8_Setup_dataconfig;        // 8 bits for command
spiDAT1_t AD7175_8_data_recv_dataconfig;    // 8 bits segments for data
uint32_t spiCommand = 0;
uint32_t spiData = 0;
uint32 inputState_A0 = 0;
uint32 inputState_B2 = 0;
uint32 ledState = 0; // Global variable to maintain LED state

uint16_t rxSPIbuffer[5];  // Buffer structure with WL not set.   FIrst 24Bits is Signal Reading, nest 8bits is the status register when Data_STAT is set, the last 8bits are the CRC, when CRC is enabled
uint16_t rxSPIstatusBuffer[2];  // Buffer structure with WL not set.   FIrst 24Bits is Signal Reading, nest 8bits is the status register when Data_STAT is set, the last 8bits are the CRC, when CRC is enabled
char strNDTSensor1_Signal[11],strNDTSensor1_Noise[11],strNDTSensor2_Signal[11],strNDTSensor2_Noise[11];
char Bit16_Sensor1_Signal[7],Bit16_Sensor1_Noise[7],Bit16_Sensor2_Signal[7],Bit16_Sensor2_Noise[7]; // Variables declaration for 16 bit ADC resolution
uint16_t Sensor1_Signal=0,Sensor1_Noise=0,Sensor2_Signal=0,Sensor2_Noise=0; // Variables declaration for 16 bit ADC resolution
//uint16_t delayExecution = 0;

uint32_t ulCount = 0UL;

/* ADC Variables */
uint32 ch_count=0;

/* Power System Bits */
bool        Latch_On = 0;
bool        Power_12V_On = 0;
bool        Disable_System = 0;


/*Task Initalisation Complete Statuses */
bool        Task_1_Initialised = false;
bool        Task_2_Initialised = false;

/* Debug */
uint8_t cString[ TX_BUFFER_SIZE];
uint8_t cString_ReceiveData[ RX_BUFFER_SIZE];

struct AD7175_8_Measurements{
    uint32_t ADCvalue;
    uint8_t StatusReg;
    uint8_t CRC;
} ;
struct NDTsensors{
    struct AD7175_8_Measurements Signal;
    struct AD7175_8_Measurements Noise;
} ;

struct NDTRecords{
    struct NDTsensors NDT1;
    struct NDTsensors NDT2;
    uint32_t  Heartbeat;
} ;

struct NDTRecords NDTLog;

/* Task Handles */
xTaskHandle xDebugTaskHandle;           // Task used to send data to a serial terminal
xTaskHandle xNetworkCommsTaskHandle;    // Task to handle Ethernet network data communications
xTaskHandle xADCpollingTaskHandle;          // Task to Poll analog data
xTaskHandle xSimulinkTaskHandle;        // Task used to Run Simulink code.  Typically Power Management
xTaskHandle xInitialisationTaskHandle;  // Task Used to coordinate the intialisation of all task
xTaskHandle xAggregateTaskHandle;  // Task Used to combine all tasks other than simulink


// To reset Hercules via software...
void software_reset(void) {
    SYS_EXCEPTION = 0x10U;  // Writing 0x10 to SYS_EXCEPTION generates a software reset
}


void sciDisplayText(sciBASE_t *sci, uint8_t *text)
{

    size_t length = strlen ((const char *)text);

    while(length--)
    {
        while ((sci->FLR & 0x4) == 4);  //wait until busy
        sciSendByte(sci,*text++);      // send out text
    };
}

void sciDisplayTextLen(sciBASE_t *sci, uint8_t *text,uint32_t length)
{
    while(length--)
    {
        while ((sci->FLR & 0x4) == 4);  //wait until busy
        sciSendByte(sci,*text++);      // send out text
    };
}

void vApplicationIPNetworkEventHook( eIPCallbackEvent_t eNetworkEvent )
{
    static BaseType_t xTasksAlreadyCreated = pdFALSE;

    char printBuffer[256];
    uint32_t ulIPAddress, ulNetMask, ulGatewayAddress, ulDNSServerAddress;
    int8_t cBuffer[16];

    sciDisplayText(sciREGx,"Network Status ...");

    /* Check this was a network up event, as opposed to a network down event. */
    if( eNetworkEvent == eNetworkUp )
    {
        /* The network is up and configured.  Print out the configuration
        obtained from the DHCP server. */
        FreeRTOS_GetAddressConfiguration( &ulIPAddress,
                                          &ulNetMask,
                                          &ulGatewayAddress,
                                          &ulDNSServerAddress );

        /* Convert the IP address to a string then print it out. */
        FreeRTOS_inet_ntoa( ulIPAddress, cBuffer );
        sprintf(printBuffer,"IP Address: %s\r\n", cBuffer );
        sciDisplayText(sciREGx,(uint8_t *)printBuffer);

        /* Convert the net mask to a string then print it out. */
        FreeRTOS_inet_ntoa( ulNetMask, cBuffer );
        sprintf(printBuffer,"Subnet Mask: %s\r\n", cBuffer );
        sciDisplayText(sciREGx,(uint8_t *)printBuffer);

        /* Convert the IP address of the gateway to a string then print it out. */
        FreeRTOS_inet_ntoa( ulGatewayAddress, cBuffer );
        sprintf(printBuffer,"Gateway IP Address: %s\r\n", cBuffer );
        sciDisplayText(sciREGx,(uint8_t *)printBuffer);

        /* Convert the IP address of the DNS server to a string then print it out. */
        FreeRTOS_inet_ntoa( ulDNSServerAddress, cBuffer );
        sprintf(printBuffer,"DNS server IP Address: %s\r\n", cBuffer );
        sciDisplayText(sciREGx,(uint8_t *)printBuffer);

        /* Create the tasks that use the IP stack if they have not already been
        created. */
        if( xTasksAlreadyCreated == pdFALSE )
        {
            /*
             * For convenience, tasks that use FreeRTOS+UDP can be created here
             * to ensure they are not created before the network is usable.
             */

            xTasksAlreadyCreated = pdTRUE;
        }
    }
    else
    {
        sciDisplayText(sciREGx,"Network not up :(");
    }
}

/** @fn void uint16buf2HexString(uint8_t  * uint8buf,uint BufferLength,char  * HexCharArray)
*   @brief convert data to a Hex char string
*   @param[in] uint8buf         - Pointer to buffer of uint8_t members
*   @param[in] BufferLength     - unsigned integer that is the length of uint8Buf
*   @param[in] HexCharArray     - Pointer to char array of char members
*
*   @return null.
*
*    This function converts an array of 8-bit numbers to a string of Hex characters.
*
*/


static char hex[] = "0123456789ABCDEF";
void uint16buf2HexString(uint16_t  * uint16buf,size_t BufferLength,char  * HexCharArray){
    size_t i = 0;
/*
//Forward order?
    for (i = 0; i < BufferLength/2; i++)
    {
        HexCharArray[(((BufferLength/2-1)-i) * 2) + 0] = hex[((uint16buf[i] & 0x00F0) >> 4)];
        HexCharArray[(((BufferLength/2-1)-i) * 2) + 1] = hex[((uint16buf[i] & 0x000F) >> 0)];
    }
*/

    //Reverese order?
        for (i = 0; i < BufferLength/2; i++)
        {
            HexCharArray[(i * 2) + 0] = hex[((uint16buf[i] & 0x00F0) >> 4)];
            HexCharArray[(i * 2) + 1] = hex[((uint16buf[i] & 0x000F) >> 0)];
        }


    //// Add Null char at the end of the string
//    HexCharArray[(i * 2) + 2] = 0x00;
}

/*static char hex[] = "0123456789ABCDEF";
void convert_to_hex_str(char* str, uint8_t* val, size_t val_count)
{
    for (size_t i = 0; i < val_count; i++)
    {
        str[(i * 2) + 0] = hex[((val[i] & 0xF0) >> 4)];
        str[(i * 2) + 1] = hex[((val[i] & 0x0F) >> 0)];
    }
}
*/



/** @fn void SPIdataSetup(uint32_t  * Command, uint32_t  * Data, uint16 * txBuffer,int WordLength,int NumCmdWords, int NumTxWords )
*   @brief convert address and data into word length chunks to be sent
*   @param[in] Command           - Pointer to command to be sent
*   @param[in] Data    - Pointer to data to be sent
*   @param[in] txBuffer  - Pointer to Transmit buffer array of uint16_t members
*   @param[in] WordLength    - Number of characters specified in the SPI data format Data Format being transmitted
*   @param[in] NumCmdWords  - Number of words to break the command value into.
*   @param[in] NumTxWords        - Number of Words to be transmitted.
*
*   @return null.
*
*    This function populates a transfer buffer array of length equivalent to NumTxWords with data of the form address of the register or   and then data.
*/
void SPIdataSetup(uint32_t  * Command, uint32_t  * Data, uint16 * txBuffer,int WordLength,int NumCmdWords, int NumTxWords ){

    static int idataCnt = 0;

    for(idataCnt = 0;idataCnt <= NumTxWords;idataCnt = idataCnt + 1)
    {
        txBuffer[idataCnt] = 0x0;  //Reset value
        if(idataCnt <= (NumCmdWords - 1))
        {
            txBuffer[idataCnt] = (uint16_t)(*Command >> (WordLength*(idataCnt)));
        }
        else
        {
            txBuffer[idataCnt] = (uint16_t)(*Data >> (WordLength*(idataCnt - NumCmdWords)));
        }
    }

}


/*
 *  PMU Support
 */
void initialisePMU()
{
    /* PMU calibration */
    _pmuInit_();
    _pmuEnableCountersGlobal_();
    _pmuResetCounters_();
    _pmuStartCounters_(pmuCYCLE_COUNTER);
}

uint32 getPMUCycleCounter()
{
    return _pmuGetCycleCount_();
}

static uint32 totalCount;
static uint32 lastCycleCount;

void initExecutionTimer()
{
    initialisePMU();
    totalCount = 0;
    lastCycleCount = 0;
}

uint32 getExecutionTimer()
{
    uint32 cycleCount = getPMUCycleCounter();
    if (cycleCount < lastCycleCount)
    {
        /*
         *  We have an overflow...
         */

        totalCount += cycleCount +  (0xFFFFFFFF - lastCycleCount);

    }
    else
    {
       totalCount += (cycleCount-lastCycleCount)/1000;
    }

    lastCycleCount = cycleCount;

    return totalCount;
}


// Function to determine direction for a specific sensor
void determineDirection(uint8_t sensor)
{
    if (sensor == SENSOR1)
    {
        if (PROX1_A_Flag && !PROX1_B_Flag)
        {
            // Increment the direction_stable_count
            direction_stable_count++;
            if (direction_stable_count >= STABLIZING_FACTOR)
            {
                direction_stable_count = STABLIZING_FACTOR_RESET;
                prox1_Direction = PROX1_FWD_DIR; // Direction Forward
            }
        }
        else if (!PROX1_A_Flag && PROX1_B_Flag)
        {
            // Increment the direction_stable_count
            direction_stable_count++;
            if (direction_stable_count >= STABLIZING_FACTOR)
            {
                direction_stable_count = STABLIZING_FACTOR_RESET;
                prox1_Direction = PROX1_REV_DIR; // Direction Reverse
            }
        }
        else
            direction_stable_count = STABLIZING_FACTOR_RESET;
    }
    else  if (sensor == SENSOR2)
    {
        if (PROX2_A_Flag && !PROX2_B_Flag)
        {
            // Increment the direction_stable_count
            direction_stable_count2++;
            if (direction_stable_count2 >= STABLIZING_FACTOR)
            {
                direction_stable_count2 = STABLIZING_FACTOR_RESET;
                prox2_Direction = PROX2_FWD_DIR; // Direction Forward
            }
        }
        else if (!PROX2_A_Flag && PROX2_B_Flag)
        {
            // Increment the direction_stable_count
            direction_stable_count2++;
            if (direction_stable_count2 >= STABLIZING_FACTOR)
            {
                direction_stable_count2 = STABLIZING_FACTOR_RESET;
                prox2_Direction = PROX2_REV_DIR; // Direction Reverse
            }
        }
        else
            direction_stable_count2 = STABLIZING_FACTOR_RESET;
    }
}





// Function to calculate cable length for a given sensor
void calculateCableLength(uint8_t sensor, uint8_t Prox_direction,
                          uint16_t PROX_A_Counter, uint16_t PROX_B_Counter)
{
   if (sensor == SENSOR1)
    {
        // Calculate change in pulses for channel A and channel B
        delta_1A_counter = PROX_A_Counter - last_1A_counter;
        delta_1B_counter = PROX_B_Counter - last_1B_counter;

        // Update last counter values
        last_1A_counter = PROX_A_Counter;
        last_1B_counter = PROX_B_Counter;

        // Calculate cable length change based on pulses and direction
        if (Prox_direction == PROX1_FWD_DIR)
        {
            // When rope is spooled out (forward direction)
            cable_length_change1 = delta_1A_counter / (float) PULSES_PER_METER;
        }
        else if (Prox_direction == PROX1_REV_DIR)
        {
            // When rope is spooled in (reverse direction)
            cable_length_change1 = -delta_1A_counter / (float) PULSES_PER_METER;
        }

        // Update total cable length.
        cable_length_float1 += cable_length_change1;

        // Filter: Ensure cable length is within bounds (0.1m to 100m)
        if (cable_length_float1 < CABLE_MIN_LENGTH)
        {
            cable_length_float1 = CABLE_MIN_LENGTH;
        }
        else if (cable_length_float1 > CABLE_MAX_LENGTH)
        {
            cable_length_float1 =  CABLE_MAX_LENGTH;
        }

        //Problem statement: Float value once transmitted on UDP for jetson Nano, didnt parsed correct on receiver end.
        //Solution: Quick way to resolve is to convert float to integer and then transmit. So, on receiving end, integer received and then perform float type-casting.
        //Convert float to integer
        cable_length_uint1 = (uint16_t)(cable_length_float1 * FLOAT_INT_MUL_FACTOR);

    }
    else if (sensor == SENSOR2)
    {
        // Calculate change in pulses for channel A and channel B
        delta_2A_counter = PROX_A_Counter - last_2A_counter;
        delta_2B_counter = PROX_B_Counter - last_2B_counter;

        // Update last counter values
        last_2A_counter = PROX_A_Counter;
        last_2B_counter = PROX_B_Counter;

        // Calculate cable length change based on pulses and direction
        if (Prox_direction == PROX2_FWD_DIR)
        {
            // When rope is spooled out (forward direction)
            cable_length_change2 = delta_2A_counter / (float) PULSES_PER_METER;
        }
        else if (Prox_direction == PROX2_REV_DIR)
        {
            // When rope is spooled in (reverse direction)
            cable_length_change2 = -delta_2A_counter / (float) PULSES_PER_METER;
        }

        // Update total cable length
        cable_length_float2 += cable_length_change2;

        // Filter: Ensure cable length is within bounds (0.1m to 100m)
        if (cable_length_float2 < CABLE_MIN_LENGTH)
        {
            cable_length_float2 = CABLE_MIN_LENGTH;
        }
        else if (cable_length_float2 > CABLE_MAX_LENGTH)
        {
            cable_length_float2 = CABLE_MAX_LENGTH;
        }

        //Problem statement: Float value once transmitted on UDP for jetson Nano, didnt parsed correct on receiver end.
        //Solution: Quick way to resolve is to convert float to integer and then transmit. So, on receiving end, integer received and then perform float type-casting.
        //Convert float to integer
        cable_length_uint2 = (uint8_t)(cable_length_float2 * FLOAT_INT_MUL_FACTOR);

    }
}

void Sys_Reset(){

    // LHS Winch parameter reset ------
    PROX1_A_Counter =  last_1A_counter =  delta_1A_counter = direction_stable_count = prox1_Direction =  PROX1_B_Counter = last_1B_counter =  delta_1B_counter = cable_length_uint1 = S1_Err_OpenCircuit = 0;
    cable_length_float1 = cable_length_change1 = 0.0;
    PROX1_A_Flag = PROX1_B_Flag = false;

    gioSetBit(gioPORTB, 7, 0); //OFF USER LED 3


    // RHS Winch parameter reset ------
    PROX2_A_Counter =  last_2A_counter =  delta_2A_counter = direction_stable_count2 = prox2_Direction = PROX2_B_Counter = last_2B_counter =  delta_2B_counter = cable_length_uint2 = S2_Err_OpenCircuit = 0;
    cable_length_float2 = cable_length_change2 = 0.0;
    PROX2_A_Flag  = PROX2_B_Flag = false;

    gioSetBit(gioPORTB, 6, 0); //OFF USER LED 2

    //System patameters.....
    ulCount =0;
    }


// Function for proximity sensor 1
void Prox1()
{

    // Determine the direction for Sensor 1
    determineDirection(SENSOR1);
    // Determine the cable length
    calculateCableLength(SENSOR1, prox1_Direction, PROX1_A_Counter, PROX1_B_Counter);
}

// Function for proximity sensor 2
void Prox2()
{

    // Determine the direction for Sensor 2
    determineDirection(SENSOR2);
    // Determine the cable length
    calculateCableLength(SENSOR2, prox2_Direction, PROX2_A_Counter, PROX2_B_Counter);
}

// Diagnostics
void Diag_Manager()
{
    if ((Sensor1_Signal >= SENSOR_ERROR)
            && (Sensor1_Signal <= SENSOR_THRESHOLD))
    {
        S1_Err_OpenCircuit = 1;
        gioSetBit(gioPORTB, 7, 1); //ON USER LED 3
    }
    else
    {
        S1_Err_OpenCircuit = 0;
        gioSetBit(gioPORTB, 7, 0); //OFF USER LED 3
    }

    if ((Sensor2_Signal >= SENSOR_ERROR)
            && (Sensor2_Signal <= SENSOR_THRESHOLD))
    {
        S2_Err_OpenCircuit = 1;
        gioSetBit(gioPORTB, 6, 1); //ON USER LED 2
    }
    else
    {
        S2_Err_OpenCircuit = 0;
        gioSetBit(gioPORTB, 6, 0); //OFF USER LED 2
    }
}


// Function to set the socket receive timeout
void set_socket_recv_timeout( xSocket, xTimeout) {
    FreeRTOS_setsockopt(xSocket, 0, FREERTOS_SO_RCVTIMEO, &xTimeout, sizeof(xTimeout));
}


void vSimulinkTask(void *pvParameters)
{
//    ulTaskNotifyTake( pdTRUE,portMAX_DELAY);                           // (T1)Wait for Simulink code to be initialised
    Task_1_Initialised = false;
//    const TickType_t xDelay250ms = pdMS_TO_TICKS( 250 );
//    /* Send gain settings via SPI */
//    SPIdataSetup(&txDpotCmdBuffer[Gain_index], &txDpotDataBuffer[Gain_index], txSPIbuffer,8,1,2 );
//    spiTransmitData(spiREG3,&AD7175_8_data_recv_dataconfig,2, txSPIbuffer);



//    gioSetBit(gioPORTA, 1, 1); // Set opAmp high



    Task_1_Initialised = true;

//    xTaskNotifyGive( xInitialisationTaskHandle);
//    vTaskPrioritySet( xSimulinkTaskHandle, 4 );
//    vTaskPrioritySet( xInitialisationTaskHandle, 4| portPRIVILEGE_BIT  );
//    ulTaskNotifyTake( pdTRUE,portMAX_DELAY);                          // Wait for response from initailisation Task



    for(;;)
    {


        /* Simulink generated code variables Read inputs */


        //rtPwrOn = gioGetBit(gioPORTB, 1);   // //extern boolean_T rtPwrOn;              /* '<Root>/powerOn' */

        rtjetsonOn = gioGetBit(gioPORTA, 0); // //extern boolean_T rtjetsonOn;           /* '<Root>/jetsonOn' */
        rtlatch = gioGetBit(gioPORTB, 0);       //extern boolean_T rtlatch;              /* '<Root>/powerLatch' */

        /* Run Simulink generated code */
        Hercules_step();

        /* Simulink generated code variables Write to outputs */
        //gioSetBit(gioPORTA, 2, rtshutdown);             //extern boolean_T rtshutdown;           /* '<Root>/shutdown' */
        gioSetBit(gioPORTB, 4, rtjetsonFCTR);           //extern boolean_T rtjetsonFCTR;         /* '<Root>/jetsonFCTR' */
        gioSetBit(gioPORTA, 5, rtjetsonRestet);         //extern boolean_T rtjetsonRestet;       /* '<Root>/jetsonRestet' */
        gioSetBit(gioPORTA, 7, rtjetsonPwrBtn);         //extern boolean_T rtjetsonPwrBtn;       /* '<Root>/jetsonPwrBtn' */


        // //extern enPowerStates_t rtPowerState;   /* '<Root>/PowerState' */

        //extern enPowerStates_t rtpowerStateReq;/* '<Root>/powerStateReq' */

//        xTaskNotifyGive( xAggregateTaskHandle );                             //Start AggregateTaskHandleg
//        xTaskNotifyGive( xADCpollingTaskHandle );                             //Start ADC polling
//        vTaskPrioritySet( xADCpollingTaskHandle, 5 );
//        vTaskPrioritySet( xSimulinkTaskHandle, 4 );
//        ulTaskNotifyTake( pdTRUE,xDelay250ms);


        vTaskPrioritySet( xAggregateTaskHandle, 4 );


//[TODO] remove if not the right approach
//        vTaskPrioritySet( xSimulinkTaskHandle, 3 );
 //       sciDisplayText(sciREGx, "Task Simulink... \r\n");
        vTaskDelay(pdMS_TO_TICKS(TIMEOUT_100MS));  // Delay for 100 milliseconds
    }
#pragma diag_suppress 112  //Remove warning from compiler as it is intentional that the return statement can not be reached.
    vTaskDelete( NULL );

}

// ************************************************************************************************


//Aggregate
void vAggregate(void *pvParameters)
{
// Debug Task: used to send extra debug data to a terminal



        uint32_t rxDataAddressTest = 15UL;
        uint8_t ChannelCount = 0;
        uint8_t ChannelBitMask = 0;
   //     const TickType_t x20ms = 20UL / portTICK_PERIOD_MS;



        Task_2_Initialised = false;//
        /* Setup AD7175-8 to specific channel */

    //    Setup Channel 0 for NDT Sensor Signal    //
                txSPIbuffer[0] = 0x10;
                txSPIbuffer[1] = 0x80;
                txSPIbuffer[2] = 0x16; //0x10;;
                txSPIbuffer[3] = 0x00;
                txSPIbuffer[4] = 0x00;
                spiTransmitData(spiREG3,&AD7175_8_Setup_dataconfig,3,txSPIbuffer);

    //    Setup Channel 1 for NDT Sensor Signal
                txSPIbuffer[0] = 0x11;
                txSPIbuffer[1] = 0x80;
                txSPIbuffer[2] = 0x36;//0x30;
                txSPIbuffer[3] = 0x00;
                txSPIbuffer[4] = 0x00;
                spiTransmitData(spiREG3,&AD7175_8_Setup_dataconfig,3,txSPIbuffer);

    //    Setup Channel 2 for NDT Sensor Signal
                txSPIbuffer[0] = 0x12;
                txSPIbuffer[1] = 0x80;
                txSPIbuffer[2] = 0x56;//0x50;
                txSPIbuffer[3] = 0x00;
                txSPIbuffer[4] = 0x00;
                spiTransmitData(spiREG3,&AD7175_8_Setup_dataconfig,3,txSPIbuffer);

    //    Setup Channel 3 for NDT Sensor Signal
                txSPIbuffer[0] = 0x13;
                txSPIbuffer[1] = 0x80;
                txSPIbuffer[2] = 0x76;// 0x70;
                txSPIbuffer[3] = 0x00;
                txSPIbuffer[4] = 0x00;

                spiTransmitData(spiREG3,&AD7175_8_Setup_dataconfig,3,txSPIbuffer);

    //    Setup Setup Config Reg. 0
                txSPIbuffer[0] = 0x20;
                txSPIbuffer[1] = 0x1F;
                txSPIbuffer[2] = 0x00;
                txSPIbuffer[3] = 0x00;
                txSPIbuffer[4] = 0x00;
                spiTransmitData(spiREG3,&AD7175_8_Setup_dataconfig,3,txSPIbuffer);

    //    Setup  ADC Mode Register
                txSPIbuffer[0] = 0x01;
                txSPIbuffer[1] = 0x07; //0x00;
                txSPIbuffer[2] = 0x00; //Continuous conversion  //
                txSPIbuffer[3] = 0x00;
                txSPIbuffer[4] = 0x00;
                spiTransmitData(spiREG3,&AD7175_8_Setup_dataconfig,3,txSPIbuffer);

    //   Setup  Interface mode Register
                txSPIbuffer[0] = 0x02;
                txSPIbuffer[1] = 0x09; //0x01;
                txSPIbuffer[2] = 0x40;
                txSPIbuffer[3] = 0x00;
                txSPIbuffer[4] = 0x00;
                spiTransmitData(spiREG3,&AD7175_8_Setup_dataconfig,3,txSPIbuffer);

                sciDisplayText(sciREGx, "AD7175-8 Setup Complete... \r\n");
                Task_2_Initialised = true;

                // ***  vADCpolling init

//vDebugTask init
            sciDisplayText(sciREGx, "Debug Task Setup Complete... \r\n");


// **** Comms
// Network Communications Task
//Initialisation Section  Network Comms
//...... Creating Socket for data transmission ...
            xSocket_t xSocket;
            struct freertos_sockaddr xDestinationAddress;


            /* Send strings to port 9997 on IP address "192.168.169.7" on the scaler. */
            xDestinationAddress.sin_addr = FreeRTOS_inet_addr( "192.168.169.7" );
            xDestinationAddress.sin_port = FreeRTOS_htons( 9997 );

            /* Create the socket. */
            sciDisplayText(sciREGx, "Create the transmission socket... \r\n");
            xSocket = FreeRTOS_socket( FREERTOS_AF_INET,
                                      FREERTOS_SOCK_DGRAM,/*FREERTOS_SOCK_DGRAM for UDP.*/
                                      FREERTOS_IPPROTO_UDP );


            /* Check the transmission socket was created. */
            configASSERT( xSocket != FREERTOS_INVALID_SOCKET );
            if (xSocket ==  FREERTOS_INVALID_SOCKET)
            {
               sciDisplayText(sciREGx, "Transmission SOCKET INVALID \r\n");
            }
            else
            {
                sciDisplayText(sciREGx, "Transmission Socket created. \r\n");
            }


 //...... Creating separate Socket for data Reception ...

            xSocket_t xRecvSocket;
            struct freertos_sockaddr xRecvAddress;

            // Create a separate socket for receiving data.
            sciDisplayText(sciREGx, "Create the receive socket... \r\n");
            xRecvSocket = FreeRTOS_socket(FREERTOS_AF_INET,
                                          FREERTOS_SOCK_DGRAM, /* FREERTOS_SOCK_DGRAM for UDP. */
                                          FREERTOS_IPPROTO_UDP);

            /* Check the socket was created. */
            configASSERT(xRecvSocket != FREERTOS_INVALID_SOCKET);
            if (xRecvSocket == FREERTOS_INVALID_SOCKET) {
                sciDisplayText(sciREGx, "Receive SOCKET INVALID \r\n");
            } else {
                sciDisplayText(sciREGx, "Receive Socket created. \r\n");
            }

            /* Bind the receive socket to port 9998. */
            xRecvAddress.sin_port = FreeRTOS_htons(9998);
            FreeRTOS_bind(xRecvSocket, &xRecvAddress, sizeof(xRecvAddress));




            sciDisplayText(sciREGx, "Ethernet Network Comms. Setup Complete... \r\n");

            // Clear the receive buffer
            memset(cString_ReceiveData, 0, sizeof(cString_ReceiveData));


     for(;;){

                if(Sys_Reset_Flag == 33) Sys_Reset(); // System reset command from ops station
                else Sys_Reset_Flag =10;

                Prox1(); // Proximity sensor 1
                Prox2(); // Proximity sensor 2


                // ***  vADCpolling  Task
                //Read AD7175-8 channels: 4 channels
    ChannelCount = 0;
    //[TODO] Heartbeat should be tick time count
    //Set Heart Beat
    NDTLog.Heartbeat = ulCount;
      while(ChannelCount < NumEnabledChannelsBitMask){
          //Read the status register to see if a data convention has completed
          //  sciDisplayText(sciREGx, "ADCpolling  Task(1039)..... \r\n");
            txSPIbuffer[0] = 0x40;
            txSPIbuffer[1] = 0x00;
            txSPIbuffer[2] = 0x00;
            txSPIbuffer[3] = 0x00;
            txSPIbuffer[4] = 0x00;

            rxSPIstatusBuffer[0] = 0x00;
            rxSPIstatusBuffer[1] = 0x00;





            spiTransmitAndReceiveData(spiREG3,&AD7175_8_data_recv_dataconfig,2,txSPIbuffer,rxSPIstatusBuffer);
//            If Ready Bit set in status register then read new data in data register


             if((rxSPIstatusBuffer[1] >> 7) == 0){
//                 if(spiREG3->PC){
//                    spiCommand = (uint32 *)0x44;
//                    spiData = (uint32 *)0x00;
//                    SPIdataSetup(spiCommand,spiData, txSPIbuffer,8,1,4 );
                 txSPIbuffer[0] = 0x44;  //read data command
                 txSPIbuffer[1] = 0x00;
                 txSPIbuffer[2] = 0x00;
                 txSPIbuffer[3] = 0x00;
                 txSPIbuffer[4] = 0x00;

                 rxSPIbuffer[0] = 0x00;
                 rxSPIbuffer[1] = 0x00;
                 rxSPIbuffer[2] = 0x00;
                 rxSPIbuffer[3] = 0x00;
                 rxSPIbuffer[4] = 0x00;

                    spiTransmitAndReceiveData(spiREG3,&AD7175_8_data_recv_dataconfig,5,txSPIbuffer,rxSPIbuffer);



//        check which channel the data belongs too
//        Setup for no CRC, so that index 0 is status register
//      [TODO] update to 1 when CRC is in use
                rxDataAddressTest = rxSPIstatusBuffer[1] & 0x0F;
                ChannelBitMask = (uint8)pow(2,rxDataAddressTest);
                switch(rxDataAddressTest ){
                        case(cNDT1SensorCH):
                                if(!(ChannelCount & ChannelBitMask)){
 //                                   sciDisplayText(sciREGx, "cNDT1SensorCH..... \r\n");
                                    uint16buf2HexString(rxSPIbuffer,sizeof(rxSPIbuffer)-1,strNDTSensor1_Signal);
                                  //  ChannelCount |= ChannelBitMask;

                                    NDTLog.NDT1.Signal.ADCvalue = (((uint32_t)rxSPIbuffer[4])<<16)+(((uint32_t)rxSPIbuffer[3])<<8)+(((uint32_t)rxSPIbuffer[2])<<0);
                                    NDTLog.NDT1.Signal.StatusReg = rxSPIstatusBuffer[1];
                                    NDTLog.NDT1.Signal.CRC = 0;

                                    // Converting ADC to 16 bit resolution
                                    Sensor1_Signal = (uint16_t)((rxSPIbuffer[1] << 8) | rxSPIbuffer[2] );
                                    snprintf(Bit16_Sensor1_Signal, sizeof(Bit16_Sensor1_Signal), "%04X", Sensor1_Signal);

                                }
                                ChannelCount|= ChannelBitMask;
                                break;
                        case(cNDT1NoiseCH):

                                if(!(ChannelCount & ChannelBitMask)){
//                                    sciDisplayText(sciREGx, "cNDT1NoiseCH..... \r\n");
                                    uint16buf2HexString(rxSPIbuffer,sizeof(rxSPIbuffer)-1,strNDTSensor1_Noise);
                                  //  ChannelCount |= ChannelBitMask;
                                    NDTLog.NDT1.Noise.ADCvalue = (((uint32_t)rxSPIbuffer[4])<<16)+(((uint32_t)rxSPIbuffer[3])<<8)+(((uint32_t)rxSPIbuffer[2])<<0);
                                    NDTLog.NDT1.Noise.StatusReg = rxSPIstatusBuffer[1];
                                    NDTLog.NDT1.Noise.CRC = 0;

                                    // Converting ADC to 16 bit resolution
                                    Sensor1_Noise = (uint16_t)((rxSPIbuffer[1] << 8) | rxSPIbuffer[2] );
                                    snprintf(Bit16_Sensor1_Noise, sizeof(Bit16_Sensor1_Noise), "%04X", Sensor1_Noise);

                                }
                                ChannelCount |= ChannelBitMask;
                                break;
                        case(cNDT2SensorCH):

                                if(!(ChannelCount & ChannelBitMask)){
 //                                   sciDisplayText(sciREGx, "cNDT2SensorCH..... \r\n");
                                    uint16buf2HexString(rxSPIbuffer,sizeof(rxSPIbuffer)-1,strNDTSensor2_Signal);
                                  //  ChannelCount |= ChannelBitMask;
                                    NDTLog.NDT2.Signal.ADCvalue = (((uint32_t)rxSPIbuffer[4])<<16)+(((uint32_t)rxSPIbuffer[3])<<8)+(((uint32_t)rxSPIbuffer[2])<<0);
                                    NDTLog.NDT2.Signal.StatusReg = rxSPIstatusBuffer[1];
                                    NDTLog.NDT2.Signal.CRC = 0;

                                    // Converting ADC to 16 bit resolution
                                     Sensor2_Signal = (uint16_t)((rxSPIbuffer[1] << 8) | rxSPIbuffer[2] );
                                     snprintf(Bit16_Sensor2_Signal, sizeof(Bit16_Sensor2_Signal), "%04X", Sensor2_Signal);
                                }
                                ChannelCount |= ChannelBitMask;
                                break;
                        case(cNDT2NoiseCH):

                                if(!(ChannelCount & ChannelBitMask)){
//                                    sciDisplayText(sciREGx, "cNDT2NoiseCH..... \r\n");
                                    uint16buf2HexString(rxSPIbuffer,sizeof(rxSPIbuffer)-1,strNDTSensor2_Noise);
                                   // ChannelCount |= ChannelBitMask;
                                    NDTLog.NDT2.Noise.ADCvalue = (((uint32_t)rxSPIbuffer[4])<<16)+(((uint32_t)rxSPIbuffer[3])<<8)+(((uint32_t)rxSPIbuffer[2])<<0);
                                    NDTLog.NDT2.Noise.StatusReg = rxSPIstatusBuffer[1];
                                    NDTLog.NDT2.Noise.CRC = 0;

                                    // Converting ADC to 16 bit resolution
                                    Sensor2_Noise = (uint16_t)((rxSPIbuffer[1] << 8) | rxSPIbuffer[2] );
                                    snprintf(Bit16_Sensor2_Noise, sizeof(Bit16_Sensor2_Noise), "%04X", Sensor2_Noise);
                                }
                                ChannelCount |= ChannelBitMask;
                                break;
                        default:
 //                               sciDisplayText(sciREGx, "SPI Received Data source is not from any setup channels. \r\n");
                                break;
                }
            }
        }

        Diag_Manager(); // Diagnostics


        // data packaging before UDP transmission
            //        sprintf((char*) cString,
            //                "%u %u %u %u %u %u %u %f %u %u %u %u %u %u %u %f %lu \r\n",
            //                Sensor1_Signal, Sensor1_Noise, S1_Err_OpenCircuit, PROX1_A_Counter, PROX1_B_Counter, prox1_Direction, cable_length_uint1, cable_length_float1,
            //                Sensor2_Signal, Sensor2_Noise, S2_Err_OpenCircuit, PROX2_A_Counter, PROX2_B_Counter, prox2_Direction, cable_length_uint2, cable_length_float1, ulCount);



             // data packaging before UDP transmission
//        sprintf((char*) cString,
//                "%u %u %u %u %u %u %u %u %u %u %u %u %u %u %lu \r\n",
//                Sensor1_Signal, Sensor1_Noise, S1_Err_OpenCircuit,PROX1_A_Counter, PROX1_B_Counter, prox1_Direction, cable_length_uint1,
//                Sensor2_Signal, Sensor2_Noise, S2_Err_OpenCircuit, PROX2_A_Counter, PROX2_B_Counter, prox2_Direction, cable_length_uint2, ulCount);

        // For testing only
                sprintf((char*) cString,
                        "%u %u %u %u %u %u %u %u %u %u %u %u %u %u %lu %u \r\n",
                        Sensor1_Signal, Sensor1_Noise, S1_Err_OpenCircuit,PROX1_A_Counter, PROX1_B_Counter, prox1_Direction, cable_length_uint1,
                        Sensor2_Signal, Sensor2_Noise, S2_Err_OpenCircuit, PROX2_A_Counter, PROX2_B_Counter, prox2_Direction, cable_length_uint2, ulCount, Sys_Reset_Flag);

        //         display the message sent
        sciDisplayText(sciREGx, (uint8_t*) cString);

        FreeRTOS_sendto(xSocket, cString, strlen(cString), 0, &xDestinationAddress, sizeof(xDestinationAddress));


//-------- Logic to receive data from Jetson nano -------------------

        // Set the receive timeout
        set_socket_recv_timeout(xRecvSocket, pdMS_TO_TICKS(TIMEOUT_100MS));

        // Receive data from the socket
        receivedBytes = FreeRTOS_recvfrom(xRecvSocket, cString_ReceiveData, sizeof(cString_ReceiveData), 0, NULL, NULL);
      //  sizeData = sizeof(uint16_t) * 2 + sizeof(uint8_t); //  Step 3.1: This logic is commented as its to receive 3 variables as per this format:   << uint16_t | uint16_t | uint8_t
        sizeData = sizeof(uint8_t); // This logic is to only receive 1 variable of uint8_t data type

        // Ensure that data was received and it contains at least two uint16_t values and one uint8_t value
        // if (receivedBytes >= (int32_t) sizeData)  Step 3.2: This is to  receive 3 variables as per this format:   << uint16_t | uint16_t | uint8_t
         if (receivedBytes >= (uint8_t) sizeData)
        {
            if (sscanf((char*) cString_ReceiveData, " %hhu", &Sys_Reset_Flag) != 1)
            {
                printf("Error parsing received data: %s\n", cString_ReceiveData);
                continue;
            }
        }
        else if (receivedBytes == -pdFREERTOS_ERRNO_EWOULDBLOCK)
        {
            // Timeout occurred, no data received
            sciDisplayText( sciREGx, (uint8_t*) "No data received from Jetson within the timeout period\r\n");
        }
        else
        {
            sciDisplayText(sciREGx, (uint8_t*) "No data received from Jetson \r\n");
        }



//-------- [ END ] Logic to receive data from Jetson nano -------------------




                /* Increment the msg count */
                ulCount++;
//                vTaskDelay(20);  //delay of100ms
    }
    #pragma diag_suppress 112  //Remove warning from compiler as it is intentional that the return statement can not be reached.
    vTaskDelete( NULL );

}

// ************************************************************************************************


/* USER CODE END */

/** @fn void main(void)
*   @brief Application main function
*   @note This function is empty by default.
*
*   This function is called after startup.
*   The user can use this function to implement the application.
*/

/* USER CODE BEGIN (2) */

/* USER CODE END */
//[TODO]  Set MAC to Production allocated
uint8   emacAddress[6U] =   {0x0U, 0x08U, 0x00U, 0x00U, 0x00U, 0x02U};  //{0x0U, 0x08U, 0xEEU, 0x03U, 0xA6U, 0x6CU};
uint32  emacPhyAddress  =   1U;

int main(void){
/* USER CODE BEGIN (3) */

    BaseType_t returnVal = pdFALSE;

    sciInit();
    sciDisplayText(sciREGx, txtCRLF);

    sciDisplayText(sciREGx, "Initialising GIO...\r\n");
    gioInit();

    sciDisplayText(sciREGx, "Enabling Interrupt...\r\n");
    _enable_IRQ_interrupt_();

    sciDisplayText(sciREGx, "Initialising ADC...\r\n");
    adcInit();

    sciDisplayText(sciREGx, "Initialising SPI...\r\n");

    // AD7175-8 SPI setup Address and Data Frame
    AD7175_8_Setup_dataconfig.CS_HOLD =  true;
    AD7175_8_Setup_dataconfig.WDEL = true; // was org false
    AD7175_8_Setup_dataconfig.DFSEL = SPI_FMT_1;
    AD7175_8_Setup_dataconfig.CSNR = SPI_CS_2;
    // AD7175-8 SPI Data Receive Format
    AD7175_8_data_recv_dataconfig.CS_HOLD = true;  // was org false
    AD7175_8_data_recv_dataconfig.WDEL = true; // was org false
    AD7175_8_data_recv_dataconfig.DFSEL = SPI_FMT_1;
    AD7175_8_data_recv_dataconfig.CSNR = SPI_CS_2;
    spiInit();


    /*
     * Initialise the embedded Ethernet interface.  The tasks that use the
     * network are created in the vApplicationIPNetworkEventHook() hook function
     * below.  The hook function is called when the network connects.
     */
    sciDisplayText(sciREGx, "Initialising IP Layer...\r\n");

    returnVal = FreeRTOS_IPInit( ucIPAddress,
                                 ucNetMask,
                                 ucGatewayAddress,
                                 ucDNSServerAddress,
                                 emacAddress);

    if (pdFAIL == returnVal)
    {
        sciDisplayText(sciREGx, "...FAILED\r\n");
    }
    else
    {
        sciDisplayText(sciREGx, "IP Initialisation Success.\r\n");
    }


    /* Initialize Simulink */
//    sciDisplayText(sciREGx, "Initialising Simulink...\r\n");
    Hercules_initialize();

    sciDisplayText(sciREGx, "\r\nCreating Tasks...\r\n");
    /*
    // Create Task 1
    if (xTaskCreate(vTask1,"LowPri-LED2", configMINIMAL_STACK_SIZE, NULL, 1, &xTask1Handle) != pdTRUE)
    {
        // Task could not be created
        while(1);
    }
    // Create Task 2
    if (xTaskCreate(vTask2,"HighPri-LED3", configMINIMAL_STACK_SIZE, NULL, 3, &xTask2Handle) != pdTRUE)
    {
        // Task could not be created
        while(1);
    }
    */


  /*
    if (xTaskCreate(vInitialisationTask,"InitialisationTask", configMINIMAL_STACK_SIZE*1, NULL,  6, &xInitialisationTaskHandle) != pdTRUE)//| portPRIVILEGE_BIT
    {
        sciDisplayText(sciREGx, "Error Creating Initialisation Task...\r\n");
    }
    else
    {
        sciDisplayText(sciREGx, "Created Initialisation Task.\r\n");
    }
*/

    if (xTaskCreate(vSimulinkTask,"Simulink", configMINIMAL_STACK_SIZE*4, NULL,  2  , &xSimulinkTaskHandle) != pdTRUE)
    {
        sciDisplayText(sciREGx, "Error Creating Simulink Task...\r\n");
    }
    else
    {
        sciDisplayText(sciREGx, "Created Simulink Task.\r\n");
    }

    if (xTaskCreate(vAggregate,"Aggregate", configMINIMAL_STACK_SIZE*4, NULL,  3  , &xAggregateTaskHandle) != pdTRUE)
    {
        sciDisplayText(sciREGx, "Error Creating Aggregate...\r\n");
    }
    else
    {
        sciDisplayText(sciREGx, "Created Aggregate.\r\n");
    }


/*
    if (xTaskCreate(vADCpolling,"ADCpolling", configMINIMAL_STACK_SIZE*2, NULL,  6  , &xADCpollingTaskHandle) != pdTRUE)
    {
        sciDisplayText(sciREGx, "Error Creating ADC polling...\r\n");
    }
    else
    {
        sciDisplayText(sciREGx, "Created ADC polling.\r\n");
    }


    if (xTaskCreate(vEthernetCommsTask,"NetworkComms", configMINIMAL_STACK_SIZE*2, NULL,  3  , &xNetworkCommsTaskHandle) != pdTRUE)
    {
        sciDisplayText(sciREGx, "Error Creating Network Communications...\r\n");
    }
    else
    {
        sciDisplayText(sciREGx, "Created Network Communications.\r\n");
    }


    if (xTaskCreate(vDebugTask,"DebugTask", configMINIMAL_STACK_SIZE*2, NULL, 5  , &xDebugTaskHandle) != pdTRUE)
    {
        sciDisplayText(sciREGx, "Error Creating Debug Task...\r\n");
    }
    else
    {
        sciDisplayText(sciREGx, "Created Debug Task.\r\n");
    }



     */

    sciDisplayText(sciREGx, "\r\nStarting Scheduler...\r\n");

    /* Start Scheduler */
    vTaskStartScheduler(); // vTaskStartScheduler run only once and never execute again untill system reboot.

    /* Run forever */
    while(1);
#pragma diag_suppress 112  //Remove warning from compiler as it is intentional that the return statement can not be reached.
/* USER CODE END */

    return 0;
}


/* USER CODE BEGIN (4) */

// External Interrupt Routine (ISR)
void gioNotification(gioPORT_t *port, uint32 bit)
{
    PROX1_A_Flag = false;
    PROX1_B_Flag = false;
    PROX2_A_Flag = false;
    PROX2_B_Flag = false;

    if(port == gioPORTB && bit == 2)
    {
        PROX1_B_Flag = true;
        PROX1_B_Counter++;  // Increment counters for Sensor 1 based on received signal B

    }
    else if(port == gioPORTA && bit == 0)
    {
        PROX1_A_Flag = true;
        PROX1_A_Counter++;  // Increment counters for Sensor 1 based on received signal A
    }
    else
     {
           PROX1_A_Flag = PROX1_B_Flag = false ;
     }


    if(port == gioPORTA && bit == 6)
    {
        PROX2_B_Flag = true;
        PROX2_B_Counter++; // Increment counters for Sensor 2 based on received signal B
    }
    else if(port == gioPORTA && bit == 7)
    {
        PROX2_A_Flag = true;
        PROX2_A_Counter++; // Increment counters for Sensor 2 based on received signal A
    }
    else
    {
       PROX2_A_Flag = PROX2_B_Flag = false ;
    }
}
/* USER CODE END */
